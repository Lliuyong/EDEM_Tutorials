"C:\Program Files\DEM Solutions\EDEM 2020\bin\edem.exe" -c -i "C:\Users\Ove.Schoeppner\Desktop\Tutorials\11-Transfer Chute\TransferChute_NonCalibrated.dem" -r 15 -w 0.5 -g 3 -t 3.5e-05 -p 12 -R
"C:\Program Files\DEM Solutions\EDEM 2020\bin\edem.exe" -c -i "C:\Users\Ove.Schoeppner\Desktop\Tutorials\11-Transfer Chute\TransferChute_Calibrated.dem" -r 15 -w 0.5 -g 3 -t 3.5e-05 -p 12 -R
"C:\Program Files\DEM Solutions\EDEM 2020\bin\edem.exe" -c -i "C:\Users\Ove.Schoeppner\Desktop\Tutorials\11-Transfer Chute\TransferChute_StandardValues.dem" -r 15 -w 0.5 -g 3 -t 3.5e-05 -p 12 -R
