
void HMwithPressureCalculateForce( int contactIndex,
                                    const SApiTimeStepData* timeStepData,
                                    const SApiDiscreteElement* element1,
                                    const SApiDiscreteElement* element2,
                                    SApiContactModelCustomProperties* customProperties,
                                    const SApiInteraction* interaction,
                                    const SApiContact* contact,
                                    CVector* tangentialOverlap,
                                    const SApiParameterData* parameterData,
                                    SApiContactModelParticleManager* contactModelParticleManager,
                                    SApiContactResults* contactResult)
{
    if (contact->normalPhysicalOverlap <= 0.0)
    {
        return;
    }

    // Calculate the relative velocities of the elements
    CVector relVel = vvSubtract(element1->velocityAtContactPoint, element2->velocityAtContactPoint);
    CVector contactVector = ppVector(contact->contactPoint, element1->position);
    // The unit vector from the sphere centre to contact point
    CVector unitCPVect = vecNormalize(contactVector);

    // Normal and tangential components of the relative velocity at the contact point
    double factor = vvDot(unitCPVect, relVel);
    CVector relVelN = vecMultiply(unitCPVect, factor);
    CVector relVelT = vvSubtract(relVel, relVelN);

    /*****************************/
    /* Equivalent parameters     */
    /*****************************/

    // Equivalent radii & mass 
    double sqrtOverlapN = sqrt(contact->normalContactOverlap);
    double sqrtEquivRadius = getSqrtEquivRadius(element1->physicalRadius, element2->physicalRadius);
    double sqrtEquivMass = getSqrtEquivMass(element1->mass, element2->mass);

    // Effective Young's Modulus
    double equivYoungsMod = getEquivYoungsModFromShearPoisson(  element1->shearModulus, element1->poisson,
                                                                element2->shearModulus, element2->poisson);

    double equivShearMod = getEquivShearModFromShearPoisson(  element1->shearModulus, element1->poisson,
                                                              element2->shearModulus, element2->poisson);
        
    /*****************************/
    /* Normal Calculation        */
    /*****************************/
    // Normal spring constant and normal force
    double K_n = (4.0 / 3.0) * equivYoungsMod * sqrtEquivRadius;
    factor = K_n*sqrtOverlapN*sqrtOverlapN*sqrtOverlapN;
    CVector F_n = vecMultiply(unitCPVect, -factor);

    // Damping calculation
    double B = 0.0;
    if (interaction->coeffRest > 0.0)
    {
        double myLog = log(interaction->coeffRest);
        double sl = myLog * myLog;
        double tl = M_PI * M_PI;
        B = -myLog / sqrt(sl + tl);
    }

    // Are we in a loading situation?
    double S_n = 2.0 * equivYoungsMod * sqrtEquivRadius * sqrtOverlapN;
    factor = 2.0 * SQRT_5_6 * B * sqrt(S_n) * sqrtEquivMass * vecLength(relVelN);
    CVector F_nd = vecMultiply(unitCPVect, factor);

    // check for loading
    if (vvDot(relVelN, unitCPVect) > 0.0)
    {
        F_nd = vecMultiply(F_nd, -1);
    }

    CVector normalForce = vvAdd(F_n, F_nd);

    /*****************************/
    /* Tangential Calculation    */
    /*****************************/
    CVector tOverlapOld = *tangentialOverlap;
    double S_t = 8.0 * equivShearMod * sqrtEquivRadius * sqrtOverlapN;
    CVector F_t = vecMultiply(*tangentialOverlap, -S_t);

    CVector tangentialForce;
    CVector F_td;
    double ft2 = vecLengthSquared(F_t);
    double fn2 = vecLengthSquared(F_n) * interaction->staticFriction * interaction->staticFriction;
    if (ft2 > fn2)
    {
        factor = sqrt(fn2 / ft2);
        tangentialForce = vecMultiply(F_t, factor);
        *tangentialOverlap = vecMultiply(tangentialForce, -1.0 / S_t); // slippage has occurred so the tangential overlap is reduced a bit
        F_td = tangentialForce; //at this point we get energy loss from the sliding!
    }
    else
    {
        factor = -2.0 * SQRT_5_6 * B * sqrt(S_t) * sqrtEquivMass;
        F_td = vecMultiply(relVelT, factor);
        tangentialForce = vvAdd(F_t, F_td);
    }

    // This is used for aligning the code in CPU in function of calculateSurfGeomContactForce
    if ((tangentialForce.x == F_td.x && tangentialForce.y == F_td.y && tangentialForce.z == F_td.z) &&
        (tOverlapOld.x != tangentialOverlap->x || tOverlapOld.y != tangentialOverlap->y || tOverlapOld.z != tangentialOverlap->z))
    {
        CVector zeroVector = { 0.0, 0.0, 0.0 };
        F_td = zeroVector;
    }

    /********************************************/
    /* Store the contact force and torque       */
    /********************************************/
    contactResult->normalForce = normalForce;
    contactResult->usNormalForce = F_nd;
    contactResult->tangentialForce = tangentialForce;
    contactResult->usTangentialForce = F_td;
	

}

void HMwithPressureConfigForTimeStepParticleProperty(SApiElementCustomPropertyData* particleCustomProperties)
{
}

void HMwithPressureConfigForTimeStepTriangleProperty(SApiElementCustomPropertyData* triangleCustomProperties)
{

}
