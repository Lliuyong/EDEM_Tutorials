#define _CRT_SECURE_NO_WARNINGS

#include "HMwithPressure.h"
#include "HelpersV3_0_0.h"
#include <cmath>
#include "ICustomPropertyManagerApi_1_0.h"
#include <cstring>
#include <sstream>

using namespace NApi;
using namespace NApiCore;
using namespace NApiCm;
using namespace NApiHelpersV3_0_0;

namespace
{
    // Add the name for the custom property as it will appear in EDEM Analyst
    const std::string PRESSURE_PROPERTY = "APIPressure";

    const double sqrt_5_6 = 0.912870929175276855761616304668;

    double equivRadius(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return (element1.physicalRadius * element2.physicalRadius) / (element1.physicalRadius + element2.physicalRadius);
    }

    double sqrtEquivRadius(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return sqrt(equivRadius(element1, element2));
    }

    double equivMass(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return (element1.mass * element2.mass) / (element1.mass + element2.mass);
    }

    double sqrtEquivMass(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return sqrt(equivMass(element1, element2));
    }

    double equivYoungsMod(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return (2.0 * element1.shearModulus * element2.shearModulus) /
            (element2.shearModulus * (1.0 - element1.poisson) +
                element1.shearModulus * (1.0 - element2.poisson));
    }

    double equivShearMod(const NCalcForceTypesV3_0_0::SDiscreteElement& element1, const NCalcForceTypesV3_0_0::SDiscreteElement& element2)
    {
        return (element1.shearModulus * element2.shearModulus) /
            (element2.shearModulus * (2.0 - element1.poisson) +
                element1.shearModulus * (2.0 - element2.poisson));
    }

    double dampingRatio(const NCalcForceTypesV3_0_0::SInteraction& interaction)
    {
        double B = 0.0;
        if (interaction.coeffRest > 0.0)
        {
            double myLog = log(interaction.coeffRest);
            double sl = myLog * myLog;
            double tl = NApiHelpersV3_0_0::PI * NApiHelpersV3_0_0::PI;
            B = -myLog / sqrt(sl + tl);
        }
        return B;
    }

    void dampingNormalForce(const CSimple3DVector& relVel_n,
        const CSimple3DVector& unitCPVect,
        const CSimple3DVector& F_n,
        const double equivYoungsMod,
        const double sqrtEquivRadius,
        const double sqrtEquivMass,
        const double sqrtOverlapN,
        const double dampingRatio,
        CSimple3DVector& F_nd,
        CSimple3DVector& newF_n)
    {
        double S_n = 2.0 * equivYoungsMod * sqrtEquivRadius * sqrtOverlapN;
        double factor = 2.0 * sqrt_5_6 * dampingRatio * sqrt(S_n) * sqrtEquivMass * relVel_n.length();
        F_nd = unitCPVect * factor;

        //check for loading
        if (relVel_n.dot(unitCPVect) > 0.0)
        {
            F_nd = -F_nd;
        }

        newF_n = F_n + F_nd;
    }

    double tangentialStiffness(const double equivShearMod,
        const double sqrtEquivRadius,
        const double sqrtOverlapN)
    {
        return 8.0 * equivShearMod * sqrtEquivRadius * sqrtOverlapN;
    }

    CSimple3DVector tangentialForce(const CSimple3DVector& tangentialOverlap, const double tangentialStiffness)
    {
        return CSimple3DVector(tangentialOverlap.getX() * -tangentialStiffness, tangentialOverlap.getY() * -tangentialStiffness, tangentialOverlap.getZ() * -tangentialStiffness);
    }


    void dampingTangentialForce(const CSimple3DVector& relVel_t,
        const NCalcForceTypesV3_0_0::SInteraction& interaction,
        const CSimple3DVector& F_n,
        const CSimple3DVector& F_t,
        const double tangentialStiffness,
        const double sqrtEquivMass,
        const double dampingRatio,
        CSimple3DVector& tangentialOverlap,
        CSimple3DVector& F_td,   //Damping - order of these is not massively clear to me. According to paper by diRenzo this should be
        CSimple3DVector& newF_t) //before friction limit. According to Roberto is should be done after friction limit.
    {
        double ft2 = F_t.lengthSquared();
        double fn2 = F_n.lengthSquared() * interaction.staticFriction * interaction.staticFriction;

        if (ft2 > fn2)
        {
            newF_t = F_t * sqrt(fn2 / ft2);
            tangentialOverlap = newF_t * (-1.0 / tangentialStiffness); //slippage has occurred so the tangential overlap is reduced a bit

                                                                       //at this point we get energy loss from the sliding!
            F_td = newF_t;
        }
        else
        {
            //at this point we get energy loss from the damping!
            F_td = relVel_t * (-2.0 * sqrt_5_6 * dampingRatio * sqrt(tangentialStiffness) * sqrtEquivMass);
            newF_t = F_t + F_td;
        }
    }
}

NApi::EPluginModelType CPressure::getModelType()
{
    return EPluginModelType::eBase;
}

NApi::EPluginExecutionChainPosition CPressure::getExecutionChainPosition()
{
    return EPluginExecutionChainPosition::eBasePos;
}

bool CPressure::isThreadSafe()
{
    // Thread safe
    return false;
}

bool CPressure::usesCustomProperties()
{
    // Use custom properties
    return INPUT1;
}


/********************************/
/* Register 1 geometry property */
/********************************/

unsigned int CPressure::getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category)
{
	if (eGeometry == category)
	{return INPUT2;}
	else
	{return INPUT3;}
}

/*******************************/
/* Set details of the property */
/*******************************/

bool CPressure::getDetailsForProperty(unsigned int propertyIndex,
    NApi::EPluginPropertyCategory category,
    char name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
    NApi::EPluginPropertyDataTypes& dataType,
    unsigned int& numberOfElements,
    NApi::EPluginPropertyUnitTypes& unitType,
    char initValBuff[NApi::BUFF_SIZE])
{
    if (0 == propertyIndex &&  eGeometry == category)
    {
        strncpy(name, INPUT4.c_str(), CUSTOM_PROP_MAX_NAME_LENGTH); // Set name of the property
        dataType         = eDouble;
        numberOfElements = INPUT5; // Set number of elements
        unitType         = INPUT6; // Set the unit type
		std::ostringstream oss; // Declare an ostringstream (http://www.cplusplus.com/reference/iostream/ostringstream/)
        oss << INPUT7;  // Assign the value 0 to oss
        strncpy(initValBuff, oss.str().c_str(), CUSTOM_PROP_MAX_NAME_LENGTH); // Initiate the custom property with the value oss (i.e. 0)
		return true;
    }

    else
    {
        return false;
    }
}

bool CPressure::starting(NApiCore::IApiManager_1_0& apiManager, int numThreads)
{
    m_geomMgr = static_cast<NApiCore::IGeometryManagerApi_1_0*>(apiManager.getApi(eGeometryManager, 1, 0));

	if (0 == m_geomMgr)
	{
      return false;
	}

    ICustomPropertyManagerApi_1_0* geomCustPropMgr = static_cast<ICustomPropertyManagerApi_1_0*>(apiManager.getApi(eGeometryCustomPropertyManager, 1, 0));

    INPUT9 = geomCustPropMgr->getPropertyIndex(PRESSURE_PROPERTY.c_str());

    return true;
}

void CPressure::stopping(NApiCore::IApiManager_1_0& apiManager)
{
	;
}


NApi::ECalculateResult CPressure::calculateForce(int threadID,
    const NCalcForceTypesV3_0_0::STimeStepData& timeStepData,
    const NCalcForceTypesV3_0_0::SDiscreteElement& element1,
    NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
    const NCalcForceTypesV3_0_0::SDiscreteElement& element2,
    NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
    NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
    NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
    const NCalcForceTypesV3_0_0::SInteraction& interaction,
    const NCalcForceTypesV3_0_0::SContact& contact,
    NApiHelpersV3_0_0::CSimple3DVector& tangentialPhysicalOverlap,
    NCalcForceTypesV3_0_0::SContactResult& contactResults)
{
    // Although a contact might exist, we may not have actual physical overlap.
    if (contact.normalPhysicalOverlap <= 0.0)
    {
        return eSuccess;
    }

    CSimple3DVector newNormalForce;
    CSimple3DVector usNormalForce;
    CSimple3DVector dampedTangentialForce;
    CSimple3DVector unsymTangentialForce;

    // relative velocity of both surfaces at contact point
    CSimple3DVector relVel = element1.velocityAtContactPoint - element2.velocityAtContactPoint;
    CSimple3DVector unitCPVect = contact.contactPoint - element1.position;
    unitCPVect.normalise();

    //I'm going to assume that the physical and contact radius are the same for this model.
    CSimple3DVector relVel_n = unitCPVect * unitCPVect.dot(relVel);
    CSimple3DVector relVel_t = relVel - relVel_n;

    double sqrtOverlapN = std::sqrt(contact.normalPhysicalOverlap);
    // sqrt Equivalent radi
    double sqrtEquivRadius = ::sqrtEquivRadius(element1, element2);
    // sqrt Equivalent Mass
    double sqrtEquivMass = ::sqrtEquivMass(element1, element2);
    // Effective Young's Modulus
    double equivYoungsMod = ::equivYoungsMod(element1, element2);
    // Effective Shear   Modulus
    double equivShearMod = ::equivShearMod(element1, element2);

    // Normal spring constant and normal force
    double normalStiffness = (4.0 / 3.0) * equivYoungsMod * sqrtEquivRadius;
    double factor = normalStiffness * sqrtOverlapN * sqrtOverlapN * sqrtOverlapN;
    CSimple3DVector F_n = unitCPVect * -factor;

    // coeff B
    double dampingRatio = ::dampingRatio(interaction);

    // Damping calculation
    dampingNormalForce(relVel_n, unitCPVect, F_n, equivYoungsMod, sqrtEquivRadius,
        sqrtEquivMass, sqrtOverlapN, dampingRatio, usNormalForce, newNormalForce);
    // compute contact stiffness
    double tangentialStiffness = ::tangentialStiffness(equivShearMod, sqrtEquivRadius, sqrtOverlapN);

    // tangential force
    CSimple3DVector F_t = tangentialForce(tangentialPhysicalOverlap, tangentialStiffness);

    // tangential damping force
    dampingTangentialForce(relVel_t, interaction, F_n, F_t, tangentialStiffness,
        sqrtEquivMass, dampingRatio, tangentialPhysicalOverlap, unsymTangentialForce, dampedTangentialForce);

    contactResults.normalForce += newNormalForce;
    contactResults.usNormalForce += usNormalForce;
    contactResults.tangentialForce += dampedTangentialForce;
    contactResults.usTangentialForce += unsymTangentialForce;

	/***************************************/
    /*   Update Pressure Custom Property   */
    /***************************************/

    if (!element2.isSphere)
	{
		/***************************************************/
		/* Update Pressure value for this geometry element */
		/***************************************************/
		//Get pointer to delta for custom property
        double* PressureDelta = elem2CustomProperties->getDelta(INPUT10);
		PressureDelta[0]+= INPUT11;
	}

	return eSuccess;


}



void CPressure::configForTimeStep(NApiCore::ICustomPropertyDataApi_1_0* simPropData,
    NApiCore::IParticleManagerApi_1_0* particleManager,
    NApiCore::IGeometryManagerApi_1_0* geometryManager,
    double time)

{
	/**************************************************************************************/
	/*              Reset the Geometry custom property PRESSURE_PROPERTY                  */
	/*                of the geometry equipment called "Bucket"                           */
	/**************************************************************************************/

    m_geomMgr->resetCustomProperty("Bucket",INPUT12.c_str(), INPUT13);

}
