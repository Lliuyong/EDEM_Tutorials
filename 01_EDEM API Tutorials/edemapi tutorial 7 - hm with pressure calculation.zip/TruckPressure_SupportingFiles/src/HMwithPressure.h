#if !defined(CHMwithPressure_h)
#define CHMwithPressure_h

#include <string>
#include <fstream>
#include <map>

#include "IPluginContactModelV3_1_0.h"
#include "IGeometryManagerApi_1_0.h"

using namespace std;

/**
 * This class provides an implementation of IPluginContactModelV3_1_0
 */

class CPressure : public NApiCm::IPluginContactModelV3_1_0
{
    public:

        /**
         * Constructor, does nothing
         */
        CPressure() = default;

        /**
         * Destructor, does nothing
         */
        ~CPressure() = default;

        /**
         * Sets prefFileName to the empty string as this plugin has no
         * configuration
         *
         * Implementation of method from IPluginContactModelV2_4_0
         */

        //virtual void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]);

		/**
		 * Returns true to indicate plugin is thread safe
		 *
		 * Implementation of method from IPluginContactModelV3_1_0
		 */
		bool isThreadSafe() override;

		/**
		 * Returns false to indicate it does not use custom properties
		 *
		 * Implementation of method from IPluginContactModelV3_1_0
		 */
		bool usesCustomProperties() override;

        /**
         * How the model should interact with chaining
         */
        NApi::EPluginModelType getModelType() override;
        NApi::EPluginExecutionChainPosition getExecutionChainPosition() override;
		/**
		 * Executes before the simulation starts. Gets the property
		 * index of each custom property.
		 *
		 * Implementation of method from IPluginContactModelV3_1_0
		 */
		bool starting(NApiCore::IApiManager_1_0& apiManager, int numThreads) override;


		/**
		 * Does nothing
		 *
		 * Implementation of method from IPluginContactModelV3_1_0
		 */
		void stopping(NApiCore::IApiManager_1_0& apiManager) override;

        /**
         * Calculates forces when two elements are in contact
         *
         * Implementation of method from IPluginContactModelV3_1_0
         */
        NApi::ECalculateResult calculateForce(int threadID,
            const NCalcForceTypesV3_0_0::STimeStepData& timeStepData,
            const NCalcForceTypesV3_0_0::SDiscreteElement& element1,
            NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
            const NCalcForceTypesV3_0_0::SDiscreteElement& element2,
            NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
            const NCalcForceTypesV3_0_0::SInteraction& interaction,
            const NCalcForceTypesV3_0_0::SContact& contact,
            NApiHelpersV3_0_0::CSimple3DVector& tangentialPhysicalOverlap,
            NCalcForceTypesV3_0_0::SContactResult& contactResults) override;

        /**
         *
         * Implementation of method from IPluginContactModelV3_1_0
         */
        unsigned int getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category) override;

        /**
         *
         * Implementation of method from IPluginContactModelV3_1_0
         */
        bool getDetailsForProperty(unsigned int propertyIndex,
            NApi::EPluginPropertyCategory category,
            char name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
            NApi::EPluginPropertyDataTypes& dataType,
            unsigned int& numberOfElements,
            NApi::EPluginPropertyUnitTypes& unitType,
            char initValBuff[NApi::BUFF_SIZE]) override;

        /**
         * Does nothing
         *
         * Implementation of method from IPluginContactModelV3_1_0
         */
        void configForTimeStep(NApiCore::ICustomPropertyDataApi_1_0* simPropData,
            NApiCore::IParticleManagerApi_1_0* particleManager,
            NApiCore::IGeometryManagerApi_1_0* geometryManager,
            double time) override;

		private:
            NApiCore::IGeometryManagerApi_1_0* m_geomMgr;
            int INPUT8;
};

#endif
