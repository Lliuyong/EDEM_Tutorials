#define _CRT_SECURE_NO_WARNINGS

#include "CReplacementFactory.h"
#include "CParticleList.h"

#include <sstream>
#include <vector>
#include <cstring>

using namespace NApi;
using namespace NApiCore;
using namespace NApiFactory;

//Add the name for the custom property and preference file name
const string CReplacementFactory::PREFS_FILE = "Particle_Cluster_Data.txt";
const string CReplacementFactory::CREATIONTIME = "Bond Creation Time";

//initialise variables
int CNum = 0;					//number of particles in cluster
double **arrCPos;				//array for positons of particles within cluster
bool Factory_Used = false;	    // Check the custom Factory has created in the simulation 
int CCreate = 0;				//Cluster element currently being created


CReplacementFactory::CReplacementFactory() : m_minScale(10.0) 
{

}

CReplacementFactory::~CReplacementFactory()
{

}

void CReplacementFactory::getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH])
{
    // Copy in pref file name 
	strncpy(prefFileName, PREFS_FILE.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

bool CReplacementFactory::usesCustomProperties()
{
	return true;
}

bool CReplacementFactory::setup(NApiCore::IApiManager_1_0& apiManager,
                           const char                 prefFile[],
                           char*                      customMsg)
{
    ifstream prefsFile(prefFile);
	m_minScale = 1.0;
    if(!prefsFile)
	{
		string errorMessage = "Preference file not found";
		strncpy(customMsg, errorMessage.c_str(), NApi::FILE_PATH_MAX_LENGTH);
		return false;
	}
    else
    {
				//get number of particles in cluster
				prefsFile >> CNum;

				double XPos, YPos, ZPos, SF;

				//pre-allocate array to store positons
				arrCPos = new double*[CNum];

				for (int j=0; j<CNum; j++)
				{
					arrCPos[j] = new double[4];

					//write positions to array
					prefsFile >> XPos >> YPos >> ZPos >> SF;
					arrCPos[j][0] = XPos;
					arrCPos[j][1] = YPos;
					arrCPos[j][2] = ZPos;
					arrCPos[j][3] = SF;

					if (SF < m_minScale)
					{
						m_minScale = SF;
					}
					if (SF > m_maxScale)
					{
						m_maxScale = SF;
					}
				}
				
    }

    return true;
}

NApi::ECalculateResult CReplacementFactory::createParticle(
                                           double  time,
                                           double  timestep,
                                           bool&   particleCreated,
                                           bool&   additionalParticleRequired,
                                           char    type[NApi::API_BASIC_STRING_LENGTH],
                                           double& scale,
                                           double& posX,
                                           double& posY,
                                           double& posZ,
                                           double& velX,
                                           double& velY,
                                           double& velZ,
                                           double& angVelX,
                                           double& angVelY,
                                           double& angVelZ,
                                           double  orientation[9],
                                           NApiCore::ICustomPropertyDataApi_1_0* propData,
                                           NApiCore::ICustomPropertyDataApi_1_0* simData)
{
//ADD CODE HERE TO CREATE PARTICLE

	/**Check that the cusotm factory has created Particles. 
	For continous replacement will not need this boolean condition. But for continous replacement
	Also a modified bonded model must be employed (Built-in EDEM model creation only one timestep)*/	
	
	for (int thread = 0; thread < ParticleList.size(); ++thread)
	{

		if (!ParticleList[thread].empty())
		{
			/// Get last particle in the list
			CParticleDef NextParticle = ParticleList[thread].back();
			
			//populate data to create particle
			strncpy(type, NextParticle.Type, NApi::API_BASIC_STRING_LENGTH);
			scale = NextParticle.Scale *  arrCPos[CCreate][3];

			posX = NextParticle.Position.x + (NextParticle.Orientation.getXX() * arrCPos[CCreate][0] + NextParticle.Orientation.getXY() * arrCPos[CCreate][1] + NextParticle.Orientation.getXZ() * arrCPos[CCreate][2])* NextParticle.Scale;
			posY = NextParticle.Position.y + (NextParticle.Orientation.getYX()* arrCPos[CCreate][0] + NextParticle.Orientation.getYY() * arrCPos[CCreate][1] + NextParticle.Orientation.getYZ() * arrCPos[CCreate][2])* NextParticle.Scale;
			posZ = NextParticle.Position.z + (NextParticle.Orientation.getZX()* arrCPos[CCreate][0] + NextParticle.Orientation.getZY() * arrCPos[CCreate][1] + NextParticle.Orientation.getZZ() * arrCPos[CCreate][2])* NextParticle.Scale;
			velX = NextParticle.Velocity.x;
			velY = NextParticle.Velocity.y;
			velZ = NextParticle.Velocity.z;

			/**
			In this code the particles are created with initial angular velocity equal to zero
			so that the particles will move in pure translation with same magnitude as the replaced
			particle

			To use Replaced particle just use the following code :

			angVelX =  NextParticle.AngVelocity.dx();
			angVelY =  NextParticle.AngVelocity.y;
			angVelZ =  NextParticle.AngVelocity.z;
			*/

			angVelX = 0;
			angVelY = 0;
			angVelZ = 0;

			orientation[0] = NextParticle.Orientation.getXX();
			orientation[1] = NextParticle.Orientation.getXY();
			orientation[2] = NextParticle.Orientation.getXZ();
			orientation[3] = NextParticle.Orientation.getYX();
			orientation[4] = NextParticle.Orientation.getYY();
			orientation[5] = NextParticle.Orientation.getYZ();
			orientation[6] = NextParticle.Orientation.getZX();
			orientation[7] = NextParticle.Orientation.getZY();
			orientation[8] = NextParticle.Orientation.getZZ();

			//ensure factory returns
			particleCreated = true;
			additionalParticleRequired = true;
			double* m_bond_creation_time = propData->getDelta(CREATIONTIME.c_str());
			m_bond_creation_time[0] += time;

			CCreate++;

			if ( CCreate == CNum)
			{
				//clean memory
				ParticleList[thread].pop_back();
				// Remove from list
				CCreate = 0;
			}

			return eSuccess;
		}

	}

	particleCreated = false;
	additionalParticleRequired = false;

	return eSuccess;
}

void CReplacementFactory::getSmallestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const
{
	// Indicate to EDEM the type and scale of the particle that will have the smallest radius
	// so that EDEM can compute the Rayleigh time step

	strncpy(type, ParticleCluster.c_str(), NApi::API_BASIC_STRING_LENGTH);
	scale = m_minScale;
}
void CReplacementFactory::getLargestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const
{

	strncpy(type, ParticleCluster.c_str(), NApi::API_BASIC_STRING_LENGTH);
	scale = m_maxScale;
}

unsigned int CReplacementFactory::getNumberOfRequiredProperties(
	const NApi::EPluginPropertyCategory category)
{
	if (eParticle == category)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


bool CReplacementFactory::getDetailsForProperty(
	unsigned int                    propertyIndex,
	NApi::EPluginPropertyCategory   category,
	char			                 name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
	NApi::EPluginPropertyDataTypes& dataType,
	unsigned int& numberOfElements,
	NApi::EPluginPropertyUnitTypes& unitType,
	char                            initValBuff[NApi::BUFF_SIZE])
{
	if (0 == propertyIndex &&
		eParticle == category)
	{

		strncpy(name, CREATIONTIME.c_str(), NApi::CUSTOM_PROP_MAX_NAME_LENGTH);
		dataType = eDouble;
		numberOfElements = 1;
		unitType = eTime;

		return true;
	}
	else
	{
		return false;
	}
}
