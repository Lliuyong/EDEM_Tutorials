#if !defined(CReplacementFactory_h)
#define CReplacementFactory_h

#include "IPluginParticleFactoryV2_2_0.h"
#include <string>

using namespace std;

class CReplacementFactory : public NApiFactory::IPluginParticleFactoryV2_2_0
{
    public:
	
		static const std::string PREFS_FILE;
		static const std::string CREATIONTIME;
        /**
         * Constructor, does nothing
         */
        CReplacementFactory();

        /**
         * Destructor, does nothing
         */
        virtual ~CReplacementFactory();

        /**
         * Sets prefFileName to PREFS_FILE
         *
         * Implementation of method from IPluginParticleFactoryV2_2_0
         */		
		void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]);
		
		
        /**
         * Setup function called when the plugin is loaded
         * Used to read preference file
		 *
         * Implementation of method from IPluginParticleFactoryV2_2_0
         */
		virtual bool setup(NApiCore::IApiManager_1_0& apiManager,
                           const char                 prefFile[],
                           char*                      customMsg);
						   
		virtual bool usesCustomProperties();

		virtual unsigned int getNumberOfRequiredProperties(
			const NApi::EPluginPropertyCategory category);

		virtual bool getDetailsForProperty(
			unsigned int                    propertyIndex,
			NApi::EPluginPropertyCategory   category,
			char                            name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
			NApi::EPluginPropertyDataTypes& dataType,
			unsigned int& numberOfElements,
			NApi::EPluginPropertyUnitTypes& unitType,
			char                            initValBuff[NApi::BUFF_SIZE]);


        virtual NApi::ECalculateResult createParticle(double time,
            double timestep,
            bool& particleCreated,
            bool& additionalParticleRequired,
            char type[NApi::API_BASIC_STRING_LENGTH],
            double& scale,
            double& posX,
            double& posY,
            double& posZ,
            double& velX,
            double& velY,
            double& velZ,
            double& angVelX,
            double& angVelY,
            double& angVelZ,
            double orientation[9],
            NApiCore::ICustomPropertyDataApi_1_0* propData,
            NApiCore::ICustomPropertyDataApi_1_0* simData);
										   
		virtual void getSmallestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const;
        virtual void getLargestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const;
    private:

		double m_minScale;
        double m_maxScale;
};

#endif