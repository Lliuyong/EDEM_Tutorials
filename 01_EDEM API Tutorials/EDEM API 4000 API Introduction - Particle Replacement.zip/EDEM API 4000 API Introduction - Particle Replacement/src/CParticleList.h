#if !defined(cparticlelist_h)
#define cparticlelist_h

#include "HelpersV3_4_0.h"
using namespace std;
using namespace NApiHelpersV3_4_0;
#include <vector>
//create a variable to store the number of particles to be replaced

class CParticleDef
{
public:
	char				Type [256];
	double				Scale;
	CSimple3DVector		Velocity;
	CSimple3DVector		Position;
	CSimple3DVector		AngVelocity;
	CSimple3x3Matrix	Orientation;

};

typedef vector<CParticleDef> ParticleListPerThread;
extern std::vector<ParticleListPerThread> ParticleList;

extern int    NumThreadsUsed;
extern bool Factory_Used;
extern double    ScaleLim;
extern string ParticleCluster;
//extern double m_requestedBondTime;

#endif