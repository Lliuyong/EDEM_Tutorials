#ifndef __CUDACC__
#include "cudaApiCore.cuh"
#include "apiConstants.cuh"
#include "CApiContact.cuh"
#include "CApiContactResults.cuh"
#include "CApiCustomPropertyData.cuh"
#include "CApiElement.cuh"
#include "CApiFieldData.cuh"
#include "CApiInteraction.cuh"
#include "CApiParticle.cuh"
#include "CApiSimulation.cuh"
#include "CApiTotalForce.cuh"
#include "CApiGeomTriangleInfo.cuh"
#include "CApiTriangleDeformationResult.cuh"
#include "CMat3x3.cuh"
#include "CQuaternion.cuh"
#include "CUtilitiesEquations.cuh"
#include "CUtilitiesMath.cuh"
#include "CUtilitiesPrecision.cuh"
#include "CVec3.cuh"
#endif

typedef struct
{
    double m_requestedBondTime;
}SSimulationParameterData;

typedef struct
{
    double m_particleID;
}SParticleParameterData;

__device__
void externalForce(NCudaApiTypesV1_0_0::CApiParticle& particle,
    NCudaApiTypesV1_0_0::CApiSimulation& simulation,
    NCudaApiTypesV1_0_0::CApiFieldData& fieldData,
    NCudaApiTypesV1_0_0::CApiTotalForce& result)
{

    SSimulationParameterData simulationParameters = *(SSimulationParameterData*)(simulation.getParameterData());

    if (simulation.getCurrentSimulationTime() >= (simulationParameters.m_requestedBondTime - 2.0 * simulation.getCurrentSimulationTime())
        && simulation.getCurrentSimulationTime() < simulationParameters.m_requestedBondTime - simulation.getCurrentSimulationTime())
    {
        SParticleParameterData particleParameters = *(SParticleParameterData*)(particle.getParameterData());

        //real particleParam = *((__global int*)parameterData->particleParameterData);

        if (particleParameters.m_particleID == 0.0)
        {
            particle.markParticleOfInterest();
        }
    }
}

__device__
void configForTimeStepParticleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& particleProperties)
{}

__device__
void configForTimeStepTriangleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& geometryProperties)
{}

__device__
void configForTimeStepSimulationProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& simulationProperties)
{}

__device__
void calculateTriangleDeformation(NCudaApiTypesV1_0_0::CApiGeomTriangleInfo& triangle,
    NCudaApiTypesV1_0_0::CApiSimulation& simulationData,
    NCudaApiTypesV1_0_0::CApiTriangleDeformationResult& deformationResults)
{}