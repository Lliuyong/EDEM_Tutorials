#if !defined(CRemoval_h)
#define CRemoval_h


#include <string>
#include <fstream>

#include "IPluginParticleBodyForceV3_7_0.h"
#include "IParticleManagerApi_1_6.h"

// This class provides an implementation of IPluginParticleBodyForceV3_7_0

using namespace std;

class CRemoval : public NApiPbf::IPluginParticleBodyForceV3_7_0
{
public:
	/**
	* Name of the preferences file to load information from
	*/
	static const std::string PREFS_FILE;
	virtual bool usesCustomProperties() override;

	/**
	* Constructor, does nothing
	*/
	CRemoval();

	/**
	* Destructor, does nothing IPluginParticleBodyForceV3_7_0
	*/
	virtual ~CRemoval();

	bool libraryProvidesGpuSource() override;
	unsigned int getGpuSourceSize() override;
	void getGpuSource(char gpuCode[]) override;

	/**
	* Sets prefFileName to PREFS_FILE
	*
	*
	* Implementation of method from IPluginParticleBodyForceV3_7_0
	*/
	virtual void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]);

	/**
	* Returns true to indicate plugin is thread safe
	*
	* Implementation of method from IPluginParticleBodyForceV3_7_0
	*/
	virtual bool isThreadSafe();

	virtual void getGpuFileName(char nameFile[NApi::API_BASIC_STRING_LENGTH]) override;

	/**
	* Setup function called when the plugin is loaded
	* Used to read preference file
	*
	* Implementation of method from IPluginParticleBodyForceV3_7_0
	*/
	virtual bool setup(NApiCore::IApiManager_1_0& apiManager,
		const char                 prefFile[],
		char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH]);


	/**
	* Called at the beginning of the processing
	*
	* Implementation of method from IPluginParticleBodyForceV3_7_0
	*/
	virtual bool starting(NApiCore::IApiManager_1_0& apiManager,
		int numThreads,
		char guiPath[NApi::GUI_FILE_MAX_LENGTH]);


	/**
	* Applies a force to the particle
	*
	* Implementation of method from IPluginParticleBodyForceV3_7_0
	*/
	virtual NApi::ECalculateResult externalForce(int threadID,
		const NExternalForceTypesV3_4_0::STimeStepData& timeStepData,
		const NExternalForceTypesV3_4_0::SParticle& particle,
		NApiCore::ICustomPropertyDataApi_1_0* particleCustomProperties,
		NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
		NExternalForceTypesV3_4_0::SResults& results) override;

	virtual unsigned int getParticleParameterData(const char particleType[], void* parameterData) override;

	virtual unsigned int getSimulationParameterData(void * 	parameterData) override;

	virtual bool usesParticleOfInterest()  const override;

	virtual void processParticleOfInterest(int threadID, int particleOfInterestId) override;

private:

	/** particle manager. */
	NApiCore::IParticleManagerApi_1_6* m_particleMngr;
};

#endif
