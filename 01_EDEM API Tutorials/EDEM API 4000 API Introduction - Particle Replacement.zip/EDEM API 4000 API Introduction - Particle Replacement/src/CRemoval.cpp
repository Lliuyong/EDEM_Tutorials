#define _CRT_SECURE_NO_WARNINGS

#include "CRemoval.h"
#include "CParticleList.h"

#include <fstream>
#include <string>
#include <fstream>
#include <sstream>

#include<cstring>
#include "HelpersV3_4_0.h"

using namespace std;
using namespace NApi;
using namespace NApiCore;
using namespace NApiPbf;
using namespace NApiHelpersV3_4_0;

//Add the name for the preference file
const string CRemoval::PREFS_FILE = "Particle_Replacement_prefs.txt";

const char* GPU_SOURCE = R"(
typedef struct
{
    double m_requestedBondTime;
}SSimulationParameterData;

typedef struct
{
    double m_particleID;
}SParticleParameterData;

__device__
void externalForce(NCudaApiTypesV1_0_0::CApiParticle& particle,
    NCudaApiTypesV1_0_0::CApiSimulation& simulation,
    NCudaApiTypesV1_0_0::CApiFieldData& fieldData,
    NCudaApiTypesV1_0_0::CApiTotalForce& result)
{

    SSimulationParameterData simulationParameters = *(SSimulationParameterData*)(simulation.getParameterData());

    if (simulation.getCurrentSimulationTime() >= (simulationParameters.m_requestedBondTime - 2.0 * simulation.getCurrentSimulationTime())
        && simulation.getCurrentSimulationTime() < simulationParameters.m_requestedBondTime - simulation.getCurrentSimulationTime())
    {
        SParticleParameterData particleParameters = *(SParticleParameterData*)(particle.getParameterData());

        //real particleParam = *((__global int*)parameterData->particleParameterData);

        if (particleParameters.m_particleID == 0.0)
        {
            particle.markParticleOfInterest();
        }
    }
}

__device__
void configForTimeStepParticleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& particleProperties)
{}

__device__
void configForTimeStepTriangleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& geometryProperties)
{}

__device__
void configForTimeStepSimulationProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& simulationProperties)
{}

__device__
void calculateTriangleDeformation(NCudaApiTypesV1_0_0::CApiGeomTriangleInfo& triangle,
    NCudaApiTypesV1_0_0::CApiSimulation& simulationData,
    NCudaApiTypesV1_0_0::CApiTriangleDeformationResult& deformationResults)
{}
)";

//variable required so factory know how many threads to search
int NumThreadsUsed;

vector<ParticleListPerThread> ParticleList;
string ParticleReplace;
string ParticleCluster;
double ScaleLim;
double m_requestedBondTime;
bool bRunEF;

bool CRemoval::usesCustomProperties()
{
	return false;
}


CRemoval::CRemoval()
{
	;
}

CRemoval::~CRemoval()
{
	;
}

void CRemoval::getPreferenceFileName(char prefFileName[FILE_PATH_MAX_LENGTH])
{
	// Copy in pref file name
	strncpy(prefFileName, PREFS_FILE.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

bool CRemoval::isThreadSafe()
{
	return true;
}

bool CRemoval::libraryProvidesGpuSource() { return true; }

unsigned int CRemoval::getGpuSourceSize() { return strlen(GPU_SOURCE); }

void CRemoval::getGpuSource(char gpuCode[]) 
{
	//printf("%s", GPU_SOURCE);
	strncpy(gpuCode, GPU_SOURCE, strlen(GPU_SOURCE));
};

void CRemoval::getGpuFileName(char nameFile[NApi::API_BASIC_STRING_LENGTH])
{
	strncpy(nameFile, "ParticleReplacementBreakage_v3_7_0", NApi::FILE_PATH_MAX_LENGTH);
}

bool CRemoval::usesParticleOfInterest() const
{
	return true;
}

bool CRemoval::setup(NApiCore::IApiManager_1_0& apiManager,
	const char                 prefFile[],
	char*                      customMsg)
{
	ifstream prefsFile(prefFile);

	if (!prefsFile)
	{
		string errorMessage = "Preference file not found";
		strncpy(customMsg, errorMessage.c_str(), NApi::FILE_PATH_MAX_LENGTH);
		return false;
	}
	else
	{
		string discard;


		prefsFile >> discard >> ParticleReplace
			>> discard >> ParticleCluster
			>> discard >> m_requestedBondTime;

	}

	return true;
}
bool CRemoval::starting(NApiCore::IApiManager_1_0& apiManager,
	int numThreads,
	char guiPath[NApi::GUI_FILE_MAX_LENGTH])
{
	m_particleMngr = static_cast<NApiCore::IParticleManagerApi_1_6*>(apiManager.getApi(eParticleManager, 1, 6));

	//create a list for each thread being used
	ParticleList.resize(numThreads);

	NumThreadsUsed = numThreads;

	return true;
}


ECalculateResult CRemoval::externalForce(int threadID,
	const NExternalForceTypesV3_4_0::STimeStepData& timeStepData,
	const NExternalForceTypesV3_4_0::SParticle& particle,
	NApiCore::ICustomPropertyDataApi_1_0* particleCustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
	NExternalForceTypesV3_4_0::SResults& results)
{
	//Must run one timestep before the factory as EDEM processes factories before EFs, this should only run once
	if (timeStepData.time >= (m_requestedBondTime - 2 * timeStepData.timeStep) && timeStepData.time < m_requestedBondTime - timeStepData.timeStep)
	{
		//check if this is the correct type of particle we want to replace
		if (strcmp(particle.type, ParticleReplace.c_str()) == 0)
		{
			m_particleMngr->markParticleOfInterest(particle.ID);
		}
	}
	return eSuccess;
}

unsigned int CRemoval::getParticleParameterData(const char particleType[], void* parameterData)
{
	//Set parameter to 0 if particleType == ParticleReplace, otherwise > 0
	*((int*)parameterData) = strcmp(particleType, ParticleReplace.c_str());
	return sizeof(int);
}
typedef struct
{
	double      m_requestedBondTime;

} SSimulationParameterData;

unsigned int CRemoval::getSimulationParameterData(void* parameterData)
{

	SSimulationParameterData* params = reinterpret_cast<SSimulationParameterData*>(parameterData);
	params->m_requestedBondTime = m_requestedBondTime;
	
	return sizeof(SSimulationParameterData);
}

void CRemoval::processParticleOfInterest(int threadID, int particleOfInterestId)
{
	NExternalForceTypesV3_4_0::SParticle particle;
	bool ret = m_particleMngr->getParticleData(particleOfInterestId, particle);

	if (particle.ID <= 0)
	{
		return;
	}

	//create list newPart to store particle info
	CParticleDef newPart;

	//write info to newPart
	strncpy(newPart.Type, ParticleCluster.c_str(), NApi::API_BASIC_STRING_LENGTH);
	newPart.Scale = m_particleMngr->getScale(particle.ID);
	newPart.Position = CSimple3DVector(particle.position.x, particle.position.y, particle.position.z);
	newPart.Velocity = CSimple3DVector(particle.velocity.x, particle.velocity.y, particle.velocity.z);
	newPart.AngVelocity = CSimple3DVector(particle.angVel.x, particle.angVel.y, particle.angVel.z);

	newPart.Orientation = CSimple3x3Matrix(particle.orientation.getXX(), particle.orientation.getXY(), particle.orientation.getXZ(),
		particle.orientation.getYX(), particle.orientation.getYY(), particle.orientation.getYZ(),
		particle.orientation.getZX(), particle.orientation.getZY(), particle.orientation.getZZ());

	//add particle to factory list
	ParticleList[threadID].push_back(newPart);

	//Particle Of Interest is removed automatically
	m_particleMngr->markForRemoval(particle.ID);
}

