#ifndef CVARIABLECOHESION_H
#define CVARIABLECOHESION_H

#include <string>
#include <vector>

#include "IPluginContactModelV3_7_0.h"
#include "CCohesionParametersList.h"
#include "IParticleManagerApi_1_6.h"

/**
 * A class that provides an implementation of IPluginContactModelV3_7_0.h
 * that performs EEPA contact force calculations
 *
 * NOTE: This version of the Archard Wear code is provided only
 * as an example of how to create a contact model plugin and is not
 * updated on a regular basis.
 */
class CVariableCohesion_v3_7_0 : public NApiCm::IPluginContactModelV3_7_0
{
    public:

        // Constructor
        CVariableCohesion_v3_7_0();

        // Destructor
        ~CVariableCohesion_v3_7_0() override;

        /**
         * Sets prefFileName to PREFERENCE_FILENAME
         *
         * Implementation of method from IPluginContactModelV3_7_0
         */
        void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]) override;

        /**
         * Returns true to indicate plugin is thread safe
         *
         * Implementation of method from IPluginContactModelV3_7_0
         */
        bool isThreadSafe() override { return true; }

        /**
         * How the model should interact with chaining
         */
        NApi::EPluginModelType getModelType() override;
        NApi::EPluginExecutionChainPosition getExecutionChainPosition() override;

        /**
         * Gets the file name of the gpu code
         * @param nameFile the location that will store the file name
         */
        void getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH]) override;

        /**
         * Setup function called when the plugin is loaded
         * Used to read preference file
         *
         * Implementation of method from IPluginContactModelV3_7_0
         */
        bool setup(NApiCore::IApiManager_1_0& apiManager,
                   const char                 prefFile[],
                   char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH]) override;



        NApi::ECalculateResult calculateForce(int threadID,
            const NCalcForceTypesV3_4_0::STimeStepData& timeStepData,
            const NCalcForceTypesV3_4_0::SDiscreteElement& element1,
            NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
            const NCalcForceTypesV3_4_0::SDiscreteElement& element2,
            NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
            const NCalcForceTypesV3_4_0::SInteraction& interaction,
            const NCalcForceTypesV3_4_0::SContact& contact,
            NApiHelpersV3_4_0::CSimple3DVector& tangentialPhysicalOverlap,
            NCalcForceTypesV3_4_0::SContactResult& contactResults) override;


        /**
         * getPartPartContactParameterData in a buffer format
         *
         * Implementation of method from IPluginContactModelV3_7_0
         *
         */
        unsigned int getPartPartContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData) override;

        /**
         * getPartGeomContactParameterData in a buffer format
         * 
         * Implementation of method from IPluginContactModelV3_7_0
         * 
         */
        unsigned int getPartGeomContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData) override;

     private:
        // Variables...

        std::string m_prefFilename;
        std::string m_gpuFileName;

        std::vector<std::string> m_particleDef;
        CCohesionParametersList m_cohesionParameters;

};

#endif
