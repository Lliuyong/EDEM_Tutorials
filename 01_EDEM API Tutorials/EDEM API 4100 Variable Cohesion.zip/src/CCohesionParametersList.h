#ifndef CCOHESIONPARAMETERSLIST_H
#define CCOHESIONPARAMETERSLIST_H

#include <map>
#include <string>

#include "CCohesionParameters.h"
/**
 * A class that retrieves parameters from a text file and adds them to a map.
 */
class CCohesionParametersList: public std::map<std::string, CCohesionParameters>
{
    public:
        /**
         * A string that is added between element names to form the key in the map
         * for that specific contact
         */
        static const std::string JOIN_STRING;

        /**
         * Adds parameters from a text file for a specific contact to the map
         *
         * @param key1 The name of the first element in the contact
         * @param key2 the name of the second element in the contact
         * @param cohesionParameters The parameter values for this contact
         */
        void addCohesionParameters(const std::string& key1,
                                   const std::string& key2,
                                   CCohesionParameters cohesionParameters);

        /**
         * Retrieves cohesion parameters from the map
         *
         * @param key1 The name of the first element in the contact
         * @param key2 the name of the second element in the contact
         */
        CCohesionParameters getCohesionParameters(const std::string& key1,
                                                  const std::string& key2);
};

#endif