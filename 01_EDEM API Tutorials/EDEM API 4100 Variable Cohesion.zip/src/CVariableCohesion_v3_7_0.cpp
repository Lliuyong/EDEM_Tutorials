#define _CRT_SECURE_NO_WARNINGS

#include "VariableCohesion_v3_7_0.h"

#include <cstring>
#include <fstream>

#include "stdlib.h"

#include "ApiIds.h"
#include "HelpersV3_4_0.h"
#include "ICustomPropertyManagerApi_1_0.h"

using namespace NApi;
using namespace NApiCore;
using namespace NApiHelpersV3_4_0;


namespace
{
    // Helper function to split string on a given character delimiter
    // Ensure that there are no spaces in the string to be split
    void split(const std::string& input, char delim, std::vector<std::string>& items)
    {
        std::string::size_type idx = 0;
        std::string::size_type pos = input.find(delim);
    
        while (pos != std::string::npos)
        {
            items.push_back(input.substr(idx, pos));
            idx = ++pos;
            pos = input.find(delim, pos);

            if (pos == std::string::npos)
            {
                items.push_back(input.substr(idx, input.length()));
            }
        }
    }
}

CVariableCohesion_v3_7_0::CVariableCohesion_v3_7_0()
{
    m_prefFilename = "cohesion_prefsV2.txt";
    m_gpuFileName = "VariableCohesion_v3_7_0";
}

CVariableCohesion_v3_7_0::~CVariableCohesion_v3_7_0()
{
}

void CVariableCohesion_v3_7_0::getPreferenceFileName(char prefFileName[FILE_PATH_MAX_LENGTH])
{
    // Expose the preference file name to the system, for use with the 
    // call to the setup() function.
	strncpy(prefFileName, m_prefFilename.c_str(), FILE_PATH_MAX_LENGTH);
}

NApi::EPluginModelType CVariableCohesion_v3_7_0::getModelType()
{
	return EPluginModelType::eOptional;
}

NApi::EPluginExecutionChainPosition CVariableCohesion_v3_7_0::getExecutionChainPosition() 
{
	return EPluginExecutionChainPosition::eAfterBasePos;
}

void CVariableCohesion_v3_7_0::getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH])
{
	strncpy(nameFile, m_gpuFileName.c_str(), FILE_PATH_MAX_LENGTH);
}

bool CVariableCohesion_v3_7_0::setup(NApiCore::IApiManager_1_0& apiManager,
                         const char                 prefFile[],
                         char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
    //Read in the preference file
    std::ifstream prefsFile(prefFile);

    if (!prefsFile.is_open())
    {
        std::string errorMessage = "Preference file not found";
		strncpy(customMsg, errorMessage.c_str(), ERROR_MSG_MAX_LENGTH);
        return false;
    }
    else
    {
        std::string description;

        double surfaceEnergy(0.0);

        std::string interaction;

        prefsFile >> description;
        
        while (prefsFile)
        {
            // Read interaction properties from preference file
			prefsFile
				>> interaction >> surfaceEnergy;

            std::vector<std::string> surfaces;
            split(interaction, ':', surfaces);

            // Add cohesion parameters to the list
            if (surfaces.size() == 2)
            {
                m_cohesionParameters.addCohesionParameters(surfaces[0],
                                                           surfaces[1],
                                                           CCohesionParameters(surfaceEnergy));
            }
            else
            {
                std::string errorMessage = "Problem reading interaction section of preference file";
				strncpy(customMsg, errorMessage.c_str(), ERROR_MSG_MAX_LENGTH);
                return false;
            }
        }
    }
    return true;
}

ECalculateResult CVariableCohesion_v3_7_0::calculateForce(int threadID,
    const NCalcForceTypesV3_4_0::STimeStepData& timeStepData,
    const NCalcForceTypesV3_4_0::SDiscreteElement& element1,
    NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
    const NCalcForceTypesV3_4_0::SDiscreteElement& element2,
    NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
    NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
    NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
    const NCalcForceTypesV3_4_0::SInteraction& interaction,
    const NCalcForceTypesV3_4_0::SContact& contact,
    NApiHelpersV3_4_0::CSimple3DVector& tangentialPhysicalOverlap,
    NCalcForceTypesV3_4_0::SContactResult& contactResults)
{
    CCohesionParameters cohesionParams = m_cohesionParameters.getCohesionParameters(element1.type, element2.type);
	
	// This contact model assumes that the Physical and the Contact radius are the same

	// The unit vector from element 1 to the contact point
	CSimple3DVector unitCPVect = contact.contactPoint - element1.position;
    unitCPVect = unitCPVect.normalize();

	//find the cohesive value (K) for the particle/geometry type from cohesion_prefsV2.txt
	double nCohesiveFactor = cohesionParams.m_surfaceEnergy;

	//Calculate Area of Contact for F=KA
	double nRadiusOfOverlapSquared = (element1.physicalRadius * element2.physicalRadius) / 
        (element1.physicalRadius + element2.physicalRadius) * contact.normalPhysicalOverlap;
	double nArea = PI * nRadiusOfOverlapSquared;

	CSimple3DVector F_cohesive = unitCPVect * nCohesiveFactor * nArea;

	contactResults.normalForce += F_cohesive;

    return ECalculateResult::eSuccess;
}

unsigned int CVariableCohesion_v3_7_0::getPartPartContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData)
{
     CCohesionParameters* params = reinterpret_cast<CCohesionParameters*>(parameterData);
    *params = m_cohesionParameters.getCohesionParameters(elem1Type, elem2Type);
    return sizeof(CCohesionParameters);
}

unsigned int CVariableCohesion_v3_7_0::getPartGeomContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData)
{
    CCohesionParameters* params = reinterpret_cast<CCohesionParameters*>(parameterData);
    *params = m_cohesionParameters.getCohesionParameters(elem1Type, elem2Type);
    return sizeof(CCohesionParameters);
}
