#ifndef CCOHESIONPARAMETERS_H
#define CCOHESIONPARAMETERS_H

class CCohesionParameters
{
    public:
        CCohesionParameters();

        CCohesionParameters(double surfaceEnergy);

		double m_surfaceEnergy;
};

#endif
