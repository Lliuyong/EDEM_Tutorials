#include "CCohesionParameters.h"

CCohesionParameters::CCohesionParameters() :
                    m_surfaceEnergy(0.0)
{}

CCohesionParameters::CCohesionParameters(double surfaceEnergy) :
                 m_surfaceEnergy(surfaceEnergy)
{}
