#define _CRT_SECURE_NO_WARNINGS

#include "CCohesionParametersList.h"

#include <vector>
#include <algorithm>

const std::string CCohesionParametersList::JOIN_STRING = "~_~_~";

void CCohesionParametersList::addCohesionParameters(const std::string& key1,
                                                    const std::string& key2,
                                                    CCohesionParameters cohesionParameters)
{
    std::vector<std::string> keys;
    keys.push_back(key1);
    keys.push_back(key2);

    //Use STL sort to put them in alphabetical order.
    std::sort(keys.begin(), keys.end());

    std::string key = keys[0] + JOIN_STRING + keys[1];
    insert(make_pair(key, cohesionParameters));
}

CCohesionParameters CCohesionParametersList::getCohesionParameters(const std::string& key1,
                                                                   const std::string& key2)
{
    std::vector<std::string> keys;
    keys.push_back(key1);
    keys.push_back(key2);

    //Use STL sort to put them in alphabetical order.
    std::sort(keys.begin(), keys.end());

    std::string nKey = keys[0] + JOIN_STRING + keys[1];

    map<std::string, CCohesionParameters>::iterator it;
    if((it = find(nKey)) != end() )
    {
        return it->second;
    }
    else
    {
        return CCohesionParameters();
    }
}
