#include "CCohesionV2.h"
#include "Helpers.h"
#include <cstring>

using namespace std;

const string CCohesionV2::PREFS_FILE = "cohesionV2_prefs.txt";
const string CCohesionV2::GPU_FILENAME = "CCohesionV2";
const string CCohesionV2::PARTICLE_PROP_NAME = "Particle Cohesive Force";
const string CCohesionV2::SIMULATION_PROP_NAME = "Cumulative Cohesive Force";
const string CCohesionV2::PARTICLE_NAME = "particle";

void CCohesionV2::getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH])
{
	// Copy in pref file name
	strncpy(prefFileName, PREFS_FILE.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

void CCohesionV2::getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH]) 
{
	// Copy in GPU file name
	strncpy(nameFile, GPU_FILENAME.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

bool CCohesionV2::setup(NApiCore::IApiManager_1_0& apiManager,
	const char                 prefFile[],
	char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
	ifstream prefsFile(prefFile);

	if (!prefsFile)
	{
		return false;
	}
	else
	{
		double energyDensity;
		string str;
		while (prefsFile)
		{
			prefsFile >> str
				>> energyDensity;

			string::size_type i(str.find(':'));
			string surfA = str.substr(0, i);
			str.erase(0, i + 1);
			string surfB = str;

			m_cohesiveItems.addCohesion(surfA, surfB, energyDensity);
		}
	}

	return true;
}


NApi::ECalculateResult CCohesionV2::calculateForce(int threadID,
	const NCalcForceTypesV3_0_0::STimeStepData& timeStepData,
	const NCalcForceTypesV3_0_0::SDiscreteElement& element1,
	NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
	const NCalcForceTypesV3_0_0::SDiscreteElement& element2,
	NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
	const NCalcForceTypesV3_0_0::SInteraction& interaction,
	const NCalcForceTypesV3_0_0::SContact& contact,
	NApiHelpersV3_0_0::CSimple3DVector& tangentialPhysicalOverlap,
	NCalcForceTypesV3_0_0::SContactResult& contactResults)
{
	// This contact model assumes that the Physical and the Contact radius
	// are the same

	// The unit vector from element 1 to the contact point
	NApiHelpersV3_0_0::CSimple3DVector unitCPVect = contact.contactPoint - element1.position;
	unitCPVect.normalise();

	double nCohesiveFactor = m_cohesiveItems.getCohesion(element1.type, element2.type);

	// RadiusofOverlapSquared = (R1 * R2)/(R1 + R2) * normalOverlap
	double nRadiusOfOverlapSquared = calculateRadiusOverlapSquared(
		element1.physicalRadius, 
		element2.physicalRadius, 
		contact.normalPhysicalOverlap);

	double nArea = NApiHelpersV3_0_0::PI * nRadiusOfOverlapSquared;

	NApiHelpersV3_0_0::CSimple3DVector F_cohesive = unitCPVect * nCohesiveFactor * nArea;

	updateCustomProperties(
		simulationCustomProperties, 
		elem1CustomProperties, 
		elem2CustomProperties, 
		element2.isSphere, 
		F_cohesive);

	contactResults.normalForce += F_cohesive;

	return NApi::eSuccess;
}

void CCohesionV2::updateCustomProperties(
	NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
	const bool elem2IsSphere,
	const NApiHelpersV3_0_0::CSimple3DVector F_cohesive
	)
{
	// Get the current delta of the custom property
	double* simCohesionDelta = simulationCustomProperties->getDelta(SIMULATION_PROP_NAME.c_str());
	double* elem1CohesionDelta = elem1CustomProperties->getDelta(PARTICLE_PROP_NAME.c_str());

	// Update components as appropriate
	simCohesionDelta[0] = F_cohesive.getX();
	simCohesionDelta[1] = F_cohesive.getY();
	simCohesionDelta[2] = F_cohesive.getZ();

	elem1CohesionDelta[0] = F_cohesive.getX();
	elem1CohesionDelta[1] = F_cohesive.getY();
	elem1CohesionDelta[2] = F_cohesive.getZ();

	// Only update element 2 if it is a particle
	if (elem2IsSphere==true)
	{
		double* elem2CohesionDelta = elem2CustomProperties->getDelta(PARTICLE_PROP_NAME.c_str());

		elem2CohesionDelta[0] = F_cohesive.getX();
		elem2CohesionDelta[1] = F_cohesive.getY();
		elem2CohesionDelta[2] = F_cohesive.getZ();	
	}
}

double CCohesionV2::calculateRadiusOverlapSquared(
	const double elem1rad, 
	const double elem2rad, 
	const double normalOverlap) 
{
	// Trivial function to calculate the radius overlap squared
	// Implemented to demonstrate how user functions are ported to CUDA

	double radiusOverlapSquared = (elem1rad * elem2rad) / (elem1rad + elem2rad) * normalOverlap;

	return radiusOverlapSquared;
}

unsigned int CCohesionV2::getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category)
{
	// We are registering one geometry and one simulation custom property
	unsigned int returnValue = 0;
	if (NApi::eParticle == category)
	{
		returnValue = 1;
	}
	else if (NApi::eSimulation == category)
	{
		returnValue = 1;
	}
	else
	{
		returnValue = 0;
	}

	return returnValue;
}

bool CCohesionV2::getDetailsForProperty(unsigned int                    propertyIndex,
	NApi::EPluginPropertyCategory   category,
	char                            name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
	NApi::EPluginPropertyDataTypes& dataType,
	unsigned int& numberOfElements,
	NApi::EPluginPropertyUnitTypes& unitType,
	char                            initValBuff[NApi::BUFF_SIZE])

{
	bool returnValue = false;
	
	// Each custom property will have 3 elements and have units of force (eForce)
	if (NApi::eParticle == category &&
		0 == propertyIndex)
	{
		strncpy(name, PARTICLE_PROP_NAME.c_str(), NApi::CUSTOM_PROP_MAX_NAME_LENGTH);
		dataType = NApi::eDouble;
		numberOfElements = 3;
		unitType = NApi::eForce;
		return true;
	}

	if (NApi::eSimulation == category &&
		0 == propertyIndex)
	{
		strncpy(name, SIMULATION_PROP_NAME.c_str(), NApi::CUSTOM_PROP_MAX_NAME_LENGTH);
		dataType = NApi::eDouble;
		numberOfElements = 3; 
		unitType = NApi::eForce;
		return true;
	}

	return returnValue;
}

void CCohesionV2::configForTimeStep(
	NApiCore::ICustomPropertyDataApi_1_0* simPropData,
	NApiCore::IParticleManagerApi_1_3* particleManager,
	NApiCore::IGeometryManagerApi_1_2* geometryManager,
	double time) 
{
	// Reset the value of the custom property for the specified particle type to 0.0
	particleManager->resetCustomProperty(PARTICLE_NAME.c_str(), PARTICLE_PROP_NAME.c_str(), 0.0);
}

unsigned int CCohesionV2::getPartPartContactParameterData(
	const char elem1Type[], const char elem2Type[], void* parameterData)
{
	double* params = reinterpret_cast<double*>(parameterData);
	*params = m_cohesiveItems.getCohesion(elem1Type, elem2Type);
	return sizeof(double);
}

unsigned int CCohesionV2::getPartGeomContactParameterData(
	const char elem1Type[], const char elem2Type[], void* parameterData)
{
	double* params = reinterpret_cast<double*>(parameterData);
	*params = m_cohesiveItems.getCohesion(elem1Type, elem2Type);
	return sizeof(double);
}
