#if !defined(CCohesionV2_h)
#define CCohesionV2_h

#include <string>
#include <fstream>

#include "IPluginContactModelV3_3_0.h"
#include "CCohesionV2List.h"

/**
 * This class provides an implementation of IPluginContactModelV3_3_0
 * That generates cohesion forces
 *
 * This plugin reads a config file from the same directory as
 * it is stored in.  The file format is any number of lines
 * defining cohesion types:
 *     type1:type_2 energy_density
 *
 * NOTE: This version of the cohesion code is
 * provided only as an example of how to create a contact model
 * plugin and is not updated on a regular basis.
 */
class CCohesionV2 : public NApiCm::IPluginContactModelV3_3_0
{
    public:
        
        /*
         * Declaration of strings to be used 
         */
        static const std::string PARTICLE_PROP_NAME;
        static const std::string SIMULATION_PROP_NAME;
        static const std::string PARTICLE_NAME;
        static const std::string PREFS_FILE;

        /**
         * Name of the GPU file 
         * from
         */
        static const std::string GPU_FILENAME;

        /**
        * Gets the file name of the gpu code
        * @param nameFile the location that will store the file name
        */
        virtual void getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH]);

        /**
         * Indicates what model type the plugin is. 
         * 
         * Implementation of method from IPluginContactModelV3_3_0
         */
        virtual NApi::EPluginModelType getModelType() { return NApi::EPluginModelType::eOptional; }

        /**
        * Indicates the position in the contact-model chain for the plugin to be executed
        * 
        * Implementation of method from IPluginContactModelV3_3_0
        */
        virtual NApi::EPluginExecutionChainPosition getExecutionChainPosition() { return NApi::EPluginExecutionChainPosition::eFinalPos; }

        /**
         * Sets prefFileName to PREFS_FILE
         *
         * Implementation of method from IPluginContactModelV3_3_0
         */
        virtual void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]);
        
        /**
         * Indicates that the plugin uses custom properties
         *
         * Implementation of method from IPluginContactModelV3_3_0
         */
        virtual bool usesCustomProperties() { return true; }

        /**
         * Reads config file
         *
         * Implementation of method from IPluginContactModelV3_3_0
         */
        
		virtual bool setup(NApiCore::IApiManager_1_0& apiManager,
                           const char                 prefFile[],
                           char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH]);
        /**
         * Generates cohesion forces
         *
         * Implementation of method from IPluginContactModelV3_3_0
         */
        virtual NApi::ECalculateResult calculateForce(int threadID,
            const NCalcForceTypesV3_0_0::STimeStepData& timeStepData,
            const NCalcForceTypesV3_0_0::SDiscreteElement& element1,
            NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
            const NCalcForceTypesV3_0_0::SDiscreteElement& element2,
            NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
            const NCalcForceTypesV3_0_0::SInteraction& interaction,
            const NCalcForceTypesV3_0_0::SContact& contact,
            NApiHelpersV3_0_0::CSimple3DVector& tangentialPhysicalOverlap,
            NCalcForceTypesV3_0_0::SContactResult& contactResults);
        
        
        /**
        * Returns the number of custom properties this plugin wants to
        * register with the system for the supplied category.
        *
        * Implementation of method from IPluginContactModelV3_3_0
        *
        */
        virtual unsigned int getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category);

        /**
        * Retrieves details for a given property.
        *
        * Implementation of method from IPluginContactModelV3_3_0
        *
        */
        virtual bool getDetailsForProperty(unsigned int propertyIndex,
            NApi::EPluginPropertyCategory category,
            char name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
            NApi::EPluginPropertyDataTypes& dataType,
            unsigned int& numberOfElements,
            NApi::EPluginPropertyUnitTypes& unitType,
            char initValBuff[NApi::BUFF_SIZE]);

        /**
         * Enables custom functionality to be carried out on a per timestep basis.
         * The function is called from the processor's performAnalysis routine at
         * the start of each timestep.
         * 
         * Implementation of method from IPluginContactModelV3_3_0
         */
        virtual void configForTimeStep(
            NApiCore::ICustomPropertyDataApi_1_0* simPropData,
            NApiCore::IParticleManagerApi_1_3* particleManager,
            NApiCore::IGeometryManagerApi_1_2* geometryManager,
            double time);

        /**
        * getPartPartContactParameterData in a buffer format
        *
        * Implementation of method from IPluginContactModelV3_3_0
        *
        */
        unsigned int getPartPartContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData) override;

        /**
        * getPartGeomContactParameterData in a buffer format
        *
        * Implementation of method from IPluginContactModelV3_3_0
        *
        */
        unsigned int getPartGeomContactParameterData(const char elem1Type[], const char elem2Type[], void* parameterData) override;

        /**
        * User defined function to calculate the radius of the overlap squared
        **/
        double calculateRadiusOverlapSquared(const double elem1rad, const double elem2rad, const double normalOverlap);
        
        /**
        * User defined function to update the custom properties
        **/
        void updateCustomProperties(
            NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
            NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
            const bool elem2IsSphere,
            const NApiHelpersV3_0_0::CSimple3DVector F_cohesive);
        
        
    private:
        CCohesionV2List m_cohesiveItems;

};

#endif
