#ifndef __CUDACC__
#include "cudaApiCore.cuh"
#include "apiConstants.cuh"
#include "CApiContact.cuh"
#include "CApiContactResults.cuh"
#include "CApiCustomPropertyData.cuh"
#include "CApiElement.cuh"
#include "CApiFieldData.cuh"
#include "CApiInteraction.cuh"
#include "CApiParticle.cuh"
#include "CApiSimulation.cuh"
#include "CApiTotalForce.cuh"
#include "CApiGeomTriangleInfo.cuh"
#include "CApiTriangleDeformationResult.cuh"
#include "CMat3x3.cuh"
#include "CQuaternion.cuh"
#include "CUtilitiesEquations.cuh"
#include "CUtilitiesMath.cuh"
#include "CUtilitiesPrecision.cuh"
#include "CVec3.cuh"
#endif


struct SFieldQueryParams
{
    double density;
    double viscosity;
};

__device__
void externalForce(NCudaApiTypesV1_0_0::CApiParticle& particle,
    NCudaApiTypesV1_0_0::CApiSimulation& simulationData,
    NCudaApiTypesV1_0_0::CApiFieldData& fieldData,
    NCudaApiTypesV1_0_0::CApiTotalForce& result)
{
    real3 cfdField;
    const SFieldQueryParams modelData = *(SFieldQueryParams*)(particle.getParameterData());
    real m_density = CUtilitiesPrecision::convertToReal(modelData.density);
    real m_viscosity = CUtilitiesPrecision::convertToReal(modelData.viscosity);

    const unsigned int fieldId = *(unsigned int*)(simulationData.getParameterData());

    // Calculate radius of particle (assuming spherical)
    real nRadius = pow(3.0 * particle.getVolume() / (4.0 * NCudaAPIConstants::PI), 1.0 / 3.0);
    // Calculate cross sectional area of particle
    real nCSA = NCudaAPIConstants::PI * nRadius * nRadius;
    
    // Apply a Buoyancy force to the particle
    real3 F_buoyancy = simulationData.getGravity() * particle.getVolume() * m_density;
    real3 fieldForce = -F_buoyancy;
    
    //find CFD Field
    fieldData.queryVectorField(fieldId, INPUT1, 8, 0, cfdField); //STEP 1
 
    // Calculate relative velocity
    real3 relativeVelocity = cfdField - INPUT2; //STEP 2

    real re = m_density * relativeVelocity.length() * 2.0 * nRadius / m_viscosity;
    //  Drag Calculation
    if (!CUtilitiesMath::isZero(re))
    {
        real m_dragCoefficient;
        if (re <= 0.5)
        {
            m_dragCoefficient = 24.0 / re;
        }
        else if (re > 0.5 && re <= 1000.0)
        {
            m_dragCoefficient = 24.0 * (1.0 + 0.15 * powf(re, 0.687)) / re;
        }
        else
        {
            m_dragCoefficient = 0.44;
        }

        //STEP 3 - Calculate the drag force on the particle
        real3 F_total = STEP3;

        //Return the force to EDEM
       fieldForce += F_total;
    }

    // Return the force to EDEM
    result.addTotalForce(fieldForce);
}

__device__
void configForTimeStepParticleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& particleProperties)
{

}

__device__
void configForTimeStepTriangleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& triangleProperties)
{

}

__device__
void configForTimeStepSimulationProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& simulationProperties)
{

}

