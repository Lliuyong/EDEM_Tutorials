#include "CFieldQuery.h"
#include "IFieldApi_1_1.h"
#include "IFieldManagerApi_1_1.h"
#include "IApiManager_1_1.h"
#include <fstream>
#include <cstring>
#include <math.h>

using namespace std;
using namespace NApi;

const string CFieldQuery::GPU_FILE = "fieldQuery_V3_8_0";
char fieldDataNames[][NApi::API_BASIC_STRING_LENGTH] = { "CFD_field" };

void CFieldQuery::setApiParametersTemplate() const
{
    // Plugin parameter manager instance for interacting with API GUI
    auto* pluginParamaterManager = getApiManager()->getParameterManager();
    // Setting up the dialog for the GUI
    pluginParamaterManager->startGroup(NPluginParamsGroupNames::PARTICLE_BODY_FORCE);
        pluginParamaterManager->startGroup("Fluid Properties Group");
            pluginParamaterManager->addDoubleValue(INPUT13); //STEP 6
            pluginParamaterManager->addDoubleValue(1e-3, "Fluid Viscosity", NApi::eViscosity);
        pluginParamaterManager->endGroup();
    pluginParamaterManager->endGroup();

    pluginParamaterManager->setParametersDialogTitle("Fluid Properties:");

}

void CFieldQuery::getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH])
{
    strncpy_s(nameFile, NApi::FILE_PATH_MAX_LENGTH, GPU_FILE.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

bool CFieldQuery::setup(NApiHelpers::CFlags<EApiBodyForceFeatureFlags>& featureFlags,
    NApiHelpers::CFlags<NApi::EApiSolverFlags>& solverFlags,
    NApiHelpers::CFlags<NApi::EApiParticleShapeFlags>& particleShapeFlags,
    const char prefFile[],
    char customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
    featureFlags.enableFlag(EApiBodyForceFeatureFlags::isThreadSafe);
    solverFlags.enableFlag(NApi::EApiSolverFlags::eCpu);
    solverFlags.enableFlag(NApi::EApiSolverFlags::eCuda);
    featureFlags.enableFlag(EApiBodyForceFeatureFlags::pluginGUIEnabled);

    //this model allows all types of shapes, but the drag model assumes they are spheres
    particleShapeFlags.enableFlag(NApi::EApiParticleShapeFlags::eMultiSphere);
    particleShapeFlags.enableFlag(NApi::EApiParticleShapeFlags::eSpheroCylinder);
    particleShapeFlags.enableFlag(NApi::EApiParticleShapeFlags::ePolyhedral);

    return true;
}

bool CFieldQuery::starting(int numThreads,
    char guiPath[NApi::GUI_FILE_MAX_LENGTH])
{
    getApiManager()->getSimulationManager()->getGravity(m_gravity);

    m_field = getApiManager()->getFieldManager()->getField(fieldDataNames[0]);
    if (!m_field)
    {
        return false;
    }

    m_velFieldId = m_field->getFieldId();

    auto* pluginParameterManager = getApiManager()->getParameterManager();
    pluginParameterManager->openGroup(NPluginParamsGroupNames::PARTICLE_BODY_FORCE);
        pluginParameterManager->openGroup("Fluid Properties Group");
            INPUT14 = pluginParameterManager->getDoubleValue("INPUT15");//STEP 7
            m_viscosity = pluginParameterManager->getDoubleValue("Fluid Viscosity");
        pluginParameterManager->endGroup();
    pluginParameterManager->endGroup();

    return true;

}

ECalculateResult CFieldQuery::externalForce(int threadID,
    const NExternalForceTypes::STimeStepData& timeStepData,
    const NExternalForceTypes::SParticle& particle,
    NApiCore::ICustomPropertyDataApi_1_0* particleCustomProperties,
    NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
    NExternalForceTypes::SResults& results)
{
    //create variables for the CFD Field
    double cfdFieldX = 0.0;
    double cfdFieldY = 0.0;
    double cfdFieldZ = 0.0;

    //Calculate radius of particle (assuming spherical)
    double nRadius = pow(3.0 * particle.volume / (4.0 * NApiHelpers::PI), 1.0 / 3.0);

    //Calculate cross sectional area of particle
    double nCSA = NApiHelpers::PI * nRadius * nRadius;

    //Apply a Buoyancy force to the particle
    NApiHelpers::CSimple3DVector F_buoyancy = m_gravity * particle.volume * m_density; 
    NApiHelpers::CSimple3DVector fieldForce(-F_buoyancy);

    //STEP 1 - Find the velocity at the particle center point and write to cfdFieldX,Y,Z
    if (m_field->queryVectorField(INPUT1, INPUT2, INPUT3, 8, eIdw, cfdFieldX, cfdFieldY, cfdFieldZ) == false)
    {
        cfdFieldX = 0;
        cfdFieldY = 0;
        cfdFieldZ = 0;
    }

    //STEP 2 - Convert the fluid velocity to a Vector called cfdField
    NApiHelpers::CSimple3DVector cfdField(INPUT4, INPUT5, INPUT6);
    //STEP 3 - Define the particle velocity vector
    NApiHelpers::CSimple3DVector particleVelocity(INPUT7, INPUT8, INPUT9);

    //STEP 4 - Find the relative velocity between particle and fluid
    NApiHelpers::CSimple3DVector relativeVelocity = INPUT10 - INPUT11;

    //Find Local Reynolds number using the relative velocity
    double re = m_density * relativeVelocity.length() * 2.0 * nRadius / m_viscosity;

    if (!NApiHelpers::isZero(re))
    {
        if (re <= 0.5)
        {
            m_dragCoefficient = 24.0 / re;
        }
        else if (re > 0.5 && re <= 1000.0)
        {
            m_dragCoefficient = 24.0 * (1.0 + 0.15 * pow(re, 0.687)) / re;
        }
        else
        {
            m_dragCoefficient = 0.44;
        }

        //STEP 5 - Calculate the drag force on the particle
        NApiHelpers::CSimple3DVector F_total = INPUT12;

        //Return the force to EDEM
        fieldForce += F_total;
    }

    results.force += fieldForce;

    return NApi::eSuccess;
}


unsigned int CFieldQuery::getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category)
{
    return 0;
}


bool CFieldQuery::getDetailsForProperty(unsigned int                    propertyIndex,
                                        NApi::EPluginPropertyCategory   category,
                                        char                            name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
                                        NApi::EPluginPropertyDataTypes& dataType,
                                        unsigned int&                   numberOfElements,
                                        NApi::EPluginPropertyUnitTypes& unitType,
                                        char                            initValBuff[NApi::BUFF_SIZE])
{
    return false;
}

unsigned int CFieldQuery::getParticleParameterData(const char particleType[], void* parameterData)
{
    SFieldQueryParams* params = reinterpret_cast<SFieldQueryParams*>(parameterData);
    if (params != nullptr)
    {
        params->density = m_density;
        params->viscosity = m_viscosity;
    }
    return sizeof(SFieldQueryParams);

}


unsigned int CFieldQuery::getSimulationParameterData(void* parameterData)
{
    *static_cast<unsigned int*>(parameterData) = m_velFieldId;
    return sizeof(unsigned int);
}