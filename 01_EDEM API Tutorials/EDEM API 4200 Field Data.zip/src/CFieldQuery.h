#ifndef CFieldQuery_h
#define CFieldQuery_h

#include <string>

#include "HelpersV3_8_0.h"

#include "IPluginParticleBodyForceV3_8_0.h"

using namespace std;
using namespace NApiPbf;

/**
 * This class provides an implementation of IPluginParticleBodyForceV3_8_0
 * That applies an fluid drag force to particles based on imported
 * field data.
  */
class CFieldQuery : public NApiPbf::IPluginParticleBodyForceV3_8_0
{
public:
    /**
     * Struct that contains parameters to be passed to the GPU implementation
     */
    struct SFieldQueryParams
    {
        double density;
        double viscosity;
    };

    /**
     * Name of the CUDA file containing plugin implementation for gpu
     */

    static const std::string GPU_FILE;
    /**
     * Constructor, does nothing
     */

    CFieldQuery() = default;

    /**
     * Destructor, does nothing
     */
    virtual ~CFieldQuery() = default;

    /**
     *Gets the name of the CUDA file
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */
    void getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH]) override;

    /**
     * Reads config file
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */

    bool setup(NApiHelpers::CFlags<EApiBodyForceFeatureFlags>& featureFlags,
        NApiHelpers::CFlags<NApi::EApiSolverFlags>& solverFlags,
        NApiHelpers::CFlags<NApi::EApiParticleShapeFlags>& particleShapeFlags,
        const char prefFile[],
        char customMsg[NApi::ERROR_MSG_MAX_LENGTH]) override;
    /**
     * Does nothing
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */
    bool starting(int numThreads,
        char guiPath[NApi::GUI_FILE_MAX_LENGTH]) override;

    /**
     * Applies an fluid drag force to particles
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */

    NApi::ECalculateResult externalForce(int threadID,
        const NExternalForceTypes::STimeStepData& timeStepData,
        const NExternalForceTypes::SParticle& particle,
        NApiCore::ICustomPropertyDataApi_1_0* particleCustomProperties,
        NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
        NExternalForceTypes::SResults& results) override;
    /**
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */
    unsigned int getNumberOfRequiredProperties(const NApi::EPluginPropertyCategory category) override;
    /**
     * Returns details for the residence time property
     *
     * Implementation of method from IPluginParticleBodyForceV3_8_0
     */
    bool getDetailsForProperty(unsigned int propertyIndex,
        NApi::EPluginPropertyCategory category,
        char name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
        NApi::EPluginPropertyDataTypes& dataType,
        unsigned int& numberOfElements,
        NApi::EPluginPropertyUnitTypes& unitType,
        char initValBuff[NApi::BUFF_SIZE]) override;

    unsigned int getParticleParameterData(const char particleType[], void* parameterData) override;

    virtual void setApiParametersTemplate() const override;

    unsigned int getSimulationParameterData(void* parameterData) override;

private:
    double                          m_dragCoefficient;
    double                          m_density;
    double                          m_viscosity;
    NApiCore::IFieldApi_1_1*        m_field;
    NApiHelpersV3_8_0::CSimple3DVector m_gravity;
    int m_velFieldId;

};

#endif
