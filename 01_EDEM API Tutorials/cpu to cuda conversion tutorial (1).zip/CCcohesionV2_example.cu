__device__
real calculateRadiusOverlapSquared(const real elem1rad, 
                                   const real elem2rad, 
                                   const real normalOverlap) 
{
	// Trivial function to calculate the radius overlap squared
	// Implemented to demonstrate how user functions are ported to CUDA

	real radiusOverlapSquared = (elem1rad * elem2rad) / (elem1rad + elem2rad) * normalOverlap;

	return radiusOverlapSquared;
}

__device__
void calculateForce(NCudaApiTypesV1_0_0::CApiElement& element1,
                    NCudaApiTypesV1_0_0::CApiElement& element2,
                    NCudaApiTypesV1_0_0::CApiInteraction& interaction,
                    NCudaApiTypesV1_0_0::CApiContact& contactData,
                    NCudaApiTypesV1_0_0::CApiSimulation& simulationData,
                    NCudaApiTypesV1_0_0::CApiContactResults& contactResult)
{
    // This contact model assumes that the Physical and the Contact radius
	// are the same
         
	// The unit vector from element 1 to the contact point
	longReal3 unitCPVect = contactData.getContactPoint() - element1.getPosition();
    unitCPVect = unitCPVect.normalize();
            
    // Get parameter data buffer. Here, it only stores one value (check getParameterData functions in cpp)
    real nCohesiveFactor = CUtilitiesPrecision::convertToReal(*(double*)(contactData.getParameterData()));
    
	// RadiusofOverlapSquared = (R1 * R2)/(R1 + R2) * normalOverlap
	real nRadiusOfOverlapSquared = calculateRadiusOverlapSquared(
        element1.getPhysicalRadius(), 
        element2.getPhysicalRadius(), 
        contactData.getNormalPhysicalOverlap());
	real nArea = NCudaAPIConstants::PI * nRadiusOfOverlapSquared;
    
	real3 F_cohesive = CUtilitiesPrecision::convertToRealVector(unitCPVect) * nCohesiveFactor * nArea;

	contactResult.addNormalForce(F_cohesive);
}

__device__
void externalForce(NCudaApiTypesV1_0_0::CApiParticle& particle,
                   NCudaApiTypesV1_0_0::CApiSimulation& simulation,
                   NCudaApiTypesV1_0_0::CApiTotalForce& result)
{
    
}

__device__
void configForTimeStepParticleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& particleProperties)
{

}

__device__
void configForTimeStepTriangleProperty(NCudaApiTypesV1_0_0::CApiCustomPropertyData& triangleProperties)
{

}
