#include "CCohesionV2.h"
#include "Helpers.h"
#include <cstring>

using namespace std;

const string CCohesionV2::PREFS_FILE = "cohesionV2_prefs.txt";
const string CCohesionV2::GPU_FILENAME = "CCohesionV2";

void CCohesionV2::getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH])
{
	// Copy in pref file name
	strncpy(prefFileName, PREFS_FILE.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

void CCohesionV2::getGpuFileName(char nameFile[NApi::FILE_PATH_MAX_LENGTH]) 
{
	// Copy in GPU file name
	strncpy(nameFile, GPU_FILENAME.c_str(), NApi::FILE_PATH_MAX_LENGTH);
}

bool CCohesionV2::setup(NApiCore::IApiManager_1_0& apiManager,
	const char                 prefFile[],
	char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
	ifstream prefsFile(prefFile);

	if (!prefsFile)
	{
		return false;
	}
	else
	{
		double energyDensity;
		string str;
		while (prefsFile)
		{
			prefsFile >> str
				>> energyDensity;

			string::size_type i(str.find(':'));
			string surfA = str.substr(0, i);
			str.erase(0, i + 1);
			string surfB = str;

			m_cohesiveItems.addCohesion(surfA, surfB, energyDensity);
		}
	}

	return true;
}


NApi::ECalculateResult CCohesionV2::calculateForce(int threadID,
	const NCalcForceTypesV3_0_0::STimeStepData& timeStepData,
	const NCalcForceTypesV3_0_0::SDiscreteElement& element1,
	NApiCore::ICustomPropertyDataApi_1_0* elem1CustomProperties,
	const NCalcForceTypesV3_0_0::SDiscreteElement& element2,
	NApiCore::ICustomPropertyDataApi_1_0* elem2CustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* contactCustomProperties,
	NApiCore::ICustomPropertyDataApi_1_0* simulationCustomProperties,
	const NCalcForceTypesV3_0_0::SInteraction& interaction,
	const NCalcForceTypesV3_0_0::SContact& contact,
	NApiHelpersV3_0_0::CSimple3DVector& tangentialPhysicalOverlap,
	NCalcForceTypesV3_0_0::SContactResult& contactResults)
{
	// This contact model assumes that the Physical and the Contact radius
	// are the same

	// The unit vector from element 1 to the contact point
	NApiHelpersV3_0_0::CSimple3DVector unitCPVect = contact.contactPoint - element1.position;
	unitCPVect.normalise();

	double nCohesiveFactor = m_cohesiveItems.getCohesion(element1.type, element2.type);

	// RadiusofOverlapSquared = (R1 * R2)/(R1 + R2) * normalOverlap
	double nRadiusOfOverlapSquared = calculateRadiusOverlapSquared(
		element1.physicalRadius, 
		element2.physicalRadius, 
		contact.normalPhysicalOverlap);
	double nArea = NApiHelpersV3_0_0::PI * nRadiusOfOverlapSquared;

	NApiHelpersV3_0_0::CSimple3DVector F_cohesive = unitCPVect * nCohesiveFactor * nArea;

	contactResults.normalForce += F_cohesive;

	return NApi::eSuccess;
}

double CCohesionV2::calculateRadiusOverlapSquared(
	const double elem1rad, 
	const double elem2rad, 
	const double normalOverlap) 
{
	// Trivial function to calculate the radius overlap squared
	// Implemented to demonstrate how user functions are ported to CUDA

	double radiusOverlapSquared = (elem1rad * elem2rad) / (elem1rad + elem2rad) * normalOverlap;

	return radiusOverlapSquared;
}

unsigned int CCohesionV2::getPartPartContactParameterData(
	const char elem1Type[], const char elem2Type[], void* parameterData)
{
	double* params = reinterpret_cast<double*>(parameterData);
	*params = m_cohesiveItems.getCohesion(elem1Type, elem2Type);
	return sizeof(double);

}

unsigned int CCohesionV2::getPartGeomContactParameterData(
	const char elem1Type[], const char elem2Type[], void* parameterData)
{
	double* params = reinterpret_cast<double*>(parameterData);
	*params = m_cohesiveItems.getCohesion(elem1Type, elem2Type);
	return sizeof(double);
}

